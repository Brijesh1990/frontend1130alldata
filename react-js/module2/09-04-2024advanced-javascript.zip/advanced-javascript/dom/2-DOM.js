/* DOM : stands for document object model  
          we can access html elements inside of javascript via calling its ID there we used DOM

          ex: document.getElementById("id")
          document.getElementById("id").value;
          document.getElementById("id").src="";
          document.getElementById("id").style;
          document.querySelector();
          document.querySelectorAll;

          


*/